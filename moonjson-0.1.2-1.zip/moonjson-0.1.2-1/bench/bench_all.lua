
print("[decode]")
loadfile("bench_decode.lua")()
print()
print("[encode]")
loadfile("bench_encode.lua")()
